import {test,expect}from'file:///C:/src/lattice-self-service-20261106/node_modules/@playwright/test/index.mjs';
test('a pending changed context clears the previous metrics and receipts',async({page})=>{
 await page.route('**/worker.js',async route=>{const response=await route.fetch();await route.fulfill({response,body:await response.text()+`\nconst original=self.onmessage;self.onmessage=event=>{if(event.data.budget===4)return new Promise(()=>{});return original(event);};\n`});});
 await page.goto('/LATTICE/');await expect(page.locator('#grains')).toHaveText('6');await expect(page.locator('#receipt')).toContainText('receipt_hash');
 await page.locator('#budget').evaluate(e=>{e.value='4';e.dispatchEvent(new Event('input'));});
 await expect(page.locator('#export')).toBeDisabled();await expect(page.locator('#grains')).toHaveText('—');await expect(page.locator('#receipt')).toHaveText('');
});
